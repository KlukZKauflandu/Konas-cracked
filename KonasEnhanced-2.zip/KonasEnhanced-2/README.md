<div align="center">

Konas Client (free & enhanced edition)

![](https://crystalpvp.ru/konas/jewnas.png)

mirrors:

[yougame.biz](https://yougame.biz/threads/224924/) / [crystalpvp.ru](https://crystalpvp.ru/konas/) / [plutonium.wtf](https://plutonium.wtf/konas/)

#
# [ info ]
Long awaited (not really) free version of [Konas Client](https://konasclient.com/)

I don't have anything to tell you besides that this "not-a-hack-but-an-utility-mod" isn't even worth $5
</div>

+ The aimware ripoff (new) GUI looks like shit and works even worse
+ The old GUI looks like moneymod+2 ([pic](https://camo.githubusercontent.com/edb1fdc23188fa30ffeacc353ac688272e6e163476063450fff383172b497b76/68747470733a2f2f692e696d6775722e636f6d2f335877536e55712e706e67))
+ The visuals are just... bad (why did Konas developers remove the old Nametags? they were a lot better)
+ The loader is absolute dogshit as almost half of the time it fails to load the client (fixed in this version LOL)
+ Konas crashes the game in singleplayer (this is **NOT** a problem of this version, Konas also crashes if you use the paid version)
+ Modules are hard to configure (mainly because of the shit GUI's)
+ Also the loader is just a [Raion](https://github.com/Ropro2002/raion-public/tree/main/src/main/java/me/cookiedragon234/falcon) paste LMAOOOO

<div align="center">
So you save $5 and get: a bad client with bad loader and bad security. I don't think that buying Konas is a wise choice...

Refund it if you can.

# [ reasons ]
This time there were actual reasons to make and upload publicly this FREE VERSION of this EPIC CLIENT
</div>

+ For reverse engineering training purposes
+ For the shit modules Konas has to offer, it doesn't cost $15
+ It's bad. You can get something like KAMI Blue/Wurst+2/Wurst+3/Phobos FOR FREE and most modules will work better than this piece of shit (and I'm not joking)
+ ^ just get rusherhack or something
+ My man cattyngmd once have won a Konas giveaway **IN THEIR OFFICIAL DISCORD SERVER**, but Darki decided to scam him, so he banned him and did a reroll ([proof](http://crystalpvp.ru/konas/scam.png))

<div align="center">

# [ how-to ]
So how do you install this FREE VERSION of COOL K LOGO CLIENT?

</div>

1. Download package.zip from the releases page
0. Put konsa_new.jar to your .minecraft folder
0. Put konsafree.jar to your .minecraft/mods folder
0. Add -noverify to your minecraft launch parameters (don't know how to do that? Tough luck.)
0. Start the game

<div align="center">

If you somehow fuck up the instructions then a message box will appear telling you exactly what did you fuck up

# [ notes ]

</div>

1. As I said, Konas devs somehow fucked up something so the game will crash if you decide to join a singleplayer world
2. Discord RPC doesnt't work if you start the game with it already being enabled (in your config)
3. You **NEED** to add -noverify to your launch parameters, otherwise the game will crash

<div align="center">

# [ credits ]

</div>

+ Konas developers - for being retarded, pasting public code and somehow making it worse
+ [mrnv/ayywareseller](https://github.com/mr-nv) - for dedicating time to create this FREE AND ENHANCED version of KONAS CLAIENT
+ [YourSleep/fuckyouthinkimboogieman](https://github.com/fuckyouthinkimboogieman) - providing an account, helping with resources
+ [PigHax](https://github.com/oyzipfile) - for attempting to demotivate me
+ [cattyngmd](https://github.com/cattyngmd) - for analysing Konas classes
+ [yoink/Katatje](https://github.com/Katatje) - running moneymod+2 back in November
